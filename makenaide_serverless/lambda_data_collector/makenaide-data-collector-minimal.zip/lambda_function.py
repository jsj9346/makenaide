#!/usr/bin/env python3
"""
Lambda Data Collector - Entry Point
AWS Lambda 함수의 메인 핸들러 파일

이 파일은 AWS Lambda에서 기본적으로 찾는 lambda_function.py 규칙을 따릅니다.
실제 로직은 data_collector.py 모듈에 구현되어 있습니다.
"""

import json
import logging
from datetime import datetime

# 로깅 설정
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    AWS Lambda 함수 진입점
    
    Args:
        event (dict): Lambda 이벤트 데이터
        context (LambdaContext): Lambda 실행 컨텍스트
        
    Returns:
        dict: HTTP 응답 형태의 결과
    """
    try:
        logger.info("🚀 Lambda 데이터 컬렉터 시작")
        logger.info(f"📥 이벤트 수신: {json.dumps(event, ensure_ascii=False, indent=2)}")
        
        # 실제 데이터 수집 로직 import (지연 로딩으로 성능 최적화)
        from data_collector_minimal import LambdaDataCollector
        
        # 데이터 컬렉터 인스턴스 생성
        collector = LambdaDataCollector()
        
        # 요청 처리
        result = collector.process_data_collection_request(event)
        
        logger.info("✅ Lambda 데이터 컬렉터 완료")
        return result
        
    except ImportError as e:
        error_msg = f"모듈 import 실패: {str(e)}"
        logger.error(f"❌ {error_msg}")
        return {
            'statusCode': 500,
            'body': {
                'success': False,
                'error': error_msg,
                'error_type': 'ImportError',
                'timestamp': datetime.now().isoformat()
            }
        }
        
    except Exception as e:
        error_msg = f"Lambda 함수 실행 실패: {str(e)}"
        logger.error(f"❌ {error_msg}")
        return {
            'statusCode': 500,
            'body': {
                'success': False,
                'error': error_msg,
                'error_type': type(e).__name__,
                'timestamp': datetime.now().isoformat()
            }
        }

# 로컬 테스트용 (Lambda 환경에서는 실행되지 않음)
if __name__ == "__main__":
    # 테스트용 이벤트
    test_event = {
        'collection_type': 'ohlcv_daily',
        'tickers': ['KRW-BTC', 'KRW-ETH'],
        'force_fetch': False
    }
    
    # 로컬 테스트 실행
    print("🧪 로컬 테스트 실행...")
    result = lambda_handler(test_event, None)
    print("📋 테스트 결과:")
    print(json.dumps(result, ensure_ascii=False, indent=2))