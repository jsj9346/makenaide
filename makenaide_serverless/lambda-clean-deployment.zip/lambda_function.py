#!/usr/bin/env python3
"""
AWS Lambda 함수: Makenaide 티커 스캐너 (깨끗한 버전)
aiohttp 없이 requests만 사용
"""

import json
import boto3
import logging
import os
import requests
from datetime import datetime, timedelta
from typing import List, Dict, Any

# 로깅 설정
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_db_connection():
    """PostgreSQL DB 연결"""
    try:
        import psycopg2
        import psycopg2.extras
    except ImportError as e:
        logger.error(f"psycopg2 import 실패: {e}")
        raise Exception("psycopg2가 사용 불가능합니다.")
    
    try:
        pg_host = os.environ.get('PG_HOST', 'makenaide.cni2ka4ugf7f.ap-northeast-2.rds.amazonaws.com')
        pg_port = int(os.environ.get('PG_PORT', '5432'))
        pg_database = os.environ.get('PG_DATABASE', 'makenaide')
        pg_user = os.environ.get('PG_USER', 'bruce')
        pg_password = os.environ.get('PG_PASSWORD')
        
        if not pg_password:
            raise Exception("PG_PASSWORD 환경변수가 설정되지 않았습니다.")
        
        logger.info(f"DB 연결 시도: {pg_host}:{pg_port}/{pg_database}")
        
        conn = psycopg2.connect(
            host=pg_host,
            port=pg_port,
            database=pg_database,
            user=pg_user,
            password=pg_password,
            connect_timeout=10
        )
        return conn
    except Exception as e:
        logger.error(f"DB 연결 실패: {e}")
        raise

def get_upbit_krw_tickers() -> List[str]:
    """Upbit REST API로 KRW 마켓 티커 목록 조회 (requests만 사용)"""
    try:
        logger.info("📡 Upbit REST API로 마켓 정보 조회 중...")
        
        url = "https://api.upbit.com/v1/market/all"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        markets_data = response.json()
        
        # KRW 마켓만 필터링
        krw_tickers = [
            market['market'] for market in markets_data 
            if market['market'].startswith('KRW-')
        ]
        
        logger.info(f"✅ Upbit REST API에서 {len(krw_tickers)}개 KRW 티커 조회 완료")
        return krw_tickers
        
    except Exception as e:
        logger.error(f"❌ Upbit API 요청 실패: {e}")
        raise Exception(f"Upbit API 티커 목록 조회 실패: {str(e)}")

def update_tickers():
    """티커 정보 업데이트"""
    try:
        logger.info("🔄 티커 정보 업데이트 시작")
        
        # Upbit에서 티커 조회
        current_tickers = get_upbit_krw_tickers()
        
        if not current_tickers:
            return False, "Upbit API 티커 목록 조회 실패"

        # DB 연결 및 업데이트
        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            # 기존 티커 조회
            cursor.execute("SELECT ticker FROM tickers")
            existing_tickers = set(row[0] for row in cursor.fetchall())

            # 신규 티커 추가
            new_tickers = set(current_tickers) - existing_tickers
            if new_tickers:
                for new_ticker in new_tickers:
                    cursor.execute(
                        "INSERT INTO tickers (ticker, created_at, is_active) VALUES (%s, CURRENT_TIMESTAMP, true)",
                        (new_ticker,)
                    )
                conn.commit()
                logger.info(f"🎉 신규 티커 추가: {len(new_tickers)}개")

            return True, {
                'total_api_tickers': len(current_tickers),
                'existing_tickers': len(existing_tickers),
                'new_tickers': len(new_tickers)
            }

        except Exception as e:
            conn.rollback()
            raise
        finally:
            cursor.close()
            conn.close()

    except Exception as e:
        logger.error(f"❌ 티커 업데이트 중 오류: {str(e)}")
        return False, str(e)

def check_db_data():
    """DB 데이터 상태 확인"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # tickers 테이블 상태 확인
        cursor.execute("SELECT COUNT(*) FROM tickers")
        ticker_count = cursor.fetchone()[0]
        
        # ohlcv 테이블 샘플 확인 (최근 데이터)
        cursor.execute("""
            SELECT ticker, COUNT(*) as record_count, 
                   MIN(date) as earliest_date, MAX(date) as latest_date
            FROM ohlcv 
            WHERE date >= CURRENT_DATE - INTERVAL '7 days'
            GROUP BY ticker 
            ORDER BY record_count DESC 
            LIMIT 5
        """)
        ohlcv_sample = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return {
            'ticker_count': ticker_count,
            'ohlcv_sample': ohlcv_sample
        }
        
    except Exception as e:
        logger.error(f"DB 데이터 확인 실패: {e}")
        return None

def lambda_handler(event, context):
    """Lambda 메인 핸들러"""
    try:
        logger.info("🚀 Makenaide 깨끗한 티커 스캐너 시작")
        start_time = datetime.now()
        
        # 1. 티커 정보 업데이트
        update_success, update_result = update_tickers()
        if not update_success:
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': f'티커 업데이트 실패: {update_result}',
                    'timestamp': datetime.now().isoformat()
                })
            }
        
        # 2. DB 데이터 상태 확인
        db_status = check_db_data()
        
        execution_time = (datetime.now() - start_time).total_seconds()
        
        result = {
            'statusCode': 200,
            'body': json.dumps({
                'message': '깨끗한 티커 스캐닝 완료',
                'update_result': update_result,
                'db_status': db_status,
                'execution_time': execution_time,
                'timestamp': datetime.now().isoformat(),
                'version': 'clean'
            })
        }
        
        logger.info(f"✅ 깨끗한 티커 스캐닝 완료")
        return result
        
    except Exception as e:
        logger.error(f"❌ 티커 스캐닝 실패: {e}")
        import traceback
        logger.error(f"상세 오류: {traceback.format_exc()}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'timestamp': datetime.now().isoformat(),
                'version': 'clean'
            })
        }
