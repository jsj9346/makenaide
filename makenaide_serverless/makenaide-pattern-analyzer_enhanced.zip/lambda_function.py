#!/usr/bin/env python3
"""
Makenaide Pattern Analyzer with Timezone Strategy Enhancement
- 시간대 기반 동적 거래 전략 적용
- 글로벌 시장 활성도에 따른 파라미터 자동 조정
- S3 기반 전략 설정 로드 및 적용
"""

import boto3
import json
import logging
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, Optional, List

# 레이어에서 시간대 전략 모듈 로드
sys.path.append('/opt/python')

try:
    from timezone_strategy_enhancer import TimezoneStrategyEnhancer, create_strategy_for_phase
    TIMEZONE_STRATEGY_AVAILABLE = True
    logger.info("시간대 전략 모듈 로드 성공")
except ImportError as e:
    TIMEZONE_STRATEGY_AVAILABLE = False
    logger.warning(f"시간대 전략 모듈 로드 실패: {e}. 기본 모드로 실행.")

# 로깅 설정
logger = logging.getLogger()
logger.setLevel(logging.INFO)

class EnhancedPatternAnalyzer:
    """시간대 전략이 통합된 pattern_analyzer 클래스"""
    
    def __init__(self):
        self.s3_client = boto3.client('s3')
        self.s3_bucket = 'makenaide-bucket-901361833359'
        
        # 기본 설정
        self.base_amount = 1000000
        self.phase_name = 'pattern_analyzer'
        
        # 시간대 전략 enhancer 초기화
        self.strategy_enhancer = None
        if TIMEZONE_STRATEGY_AVAILABLE:
            try:
                self.strategy_enhancer = TimezoneStrategyEnhancer(self.s3_bucket)
                logger.info("시간대 전략 enhancer 초기화 완료")
            except Exception as e:
                logger.warning(f"시간대 전략 enhancer 초기화 실패: {e}")
        
        # 현재 전략 설정
        self.current_strategy = None
        self.load_current_strategy_config()
    
    def load_current_strategy_config(self) -> Optional[Dict]:
        """현재 전략 설정을 S3에서 로드"""
        try:
            config_key = f'trading_strategy/current_{self.phase_name}_config.json'
            
            response = self.s3_client.get_object(
                Bucket=self.s3_bucket,
                Key=config_key
            )
            
            self.current_strategy = json.loads(response['Body'].read().decode('utf-8'))
            logger.info(f"전략 설정 로드 완료: {self.phase_name}")
            
            return self.current_strategy
            
        except self.s3_client.exceptions.NoSuchKey:
            logger.info(f"전략 설정 파일 없음 - 새로 생성: {self.phase_name}")
            return self.generate_new_strategy_config()
        except Exception as e:
            logger.warning(f"전략 설정 로드 실패: {e}")
            return None
    
    def generate_new_strategy_config(self, entry_price: float = None) -> Dict:
        """새로운 전략 설정 생성"""
        try:
            if not self.strategy_enhancer:
                logger.warning("전략 enhancer 없음 - 기본 설정 사용")
                return self._get_default_config()
            
            # 현재 BTC 가격 조회 (entry_price가 없는 경우)
            if entry_price is None:
                entry_price = self.get_current_btc_price()
            
            # 동적 전략 설정 생성
            strategy_config = self.strategy_enhancer.generate_comprehensive_strategy_config(
                entry_price=entry_price,
                base_amount=self.base_amount,
                market_volatility=0.05
            )
            
            self.current_strategy = strategy_config
            return strategy_config
            
        except Exception as e:
            logger.error(f"전략 설정 생성 실패: {e}")
            return self._get_default_config()
    
    def get_current_btc_price(self) -> float:
        """현재 BTC 가격 조회 (Upbit API)"""
        try:
            import urllib3
            
            http = urllib3.PoolManager()
            ticker_url = "https://api.upbit.com/v1/ticker?markets=KRW-BTC"
            response = http.request('GET', ticker_url)
            
            if response.status == 200:
                data = json.loads(response.data.decode('utf-8'))[0]
                return float(data['trade_price'])
            else:
                logger.warning("BTC 가격 조회 실패 - 기본값 사용")
                return 159348000  # 기본값
                
        except Exception as e:
            logger.warning(f"BTC 가격 조회 실패: {e} - 기본값 사용")
            return 159348000  # 기본값
    
    def _get_default_config(self) -> Dict:
        """기본 전략 설정"""
        return {
            'position_management': {
                'position_size_krw': self.base_amount * 0.5,
                'position_ratio': 0.5,
                'max_risk_per_trade': self.base_amount * 0.04
            },
            'risk_management': {
                'stop_loss': {
                    'stop_loss_percentage': 8.0,
                    'trailing_stop_percentage': 6.0,
                    'reason': "기본 설정"
                },
                'take_profit_levels': [
                    {'level': 1, 'target_percentage': 15.0, 'quantity_ratio': 0.3},
                    {'level': 2, 'target_percentage': 30.0, 'quantity_ratio': 0.4},
                    {'level': 3, 'target_percentage': 50.0, 'quantity_ratio': 0.3}
                ],
                'max_holding_hours': 24
            },
            'metadata': {
                'strategy_version': '2.1-default',
                'config_generated_at': datetime.utcnow().isoformat()
            }
        }
    
    def get_position_size(self, current_price: float = None) -> float:
        """동적 포지션 크기 반환"""
        if not self.current_strategy:
            return self.base_amount * 0.5
        
        return self.current_strategy.get('position_management', {}).get('position_size_krw', self.base_amount * 0.5)
    
    def get_stop_loss_config(self) -> Dict:
        """동적 손절 설정 반환"""
        if not self.current_strategy:
            return {'stop_loss_percentage': 8.0, 'trailing_stop_percentage': 6.0}
        
        return self.current_strategy.get('risk_management', {}).get('stop_loss', {})
    
    def get_take_profit_levels(self) -> List[Dict]:
        """동적 익절 레벨 반환"""
        if not self.current_strategy:
            return [
                {'level': 1, 'target_percentage': 15.0, 'quantity_ratio': 0.3},
                {'level': 2, 'target_percentage': 30.0, 'quantity_ratio': 0.4},
                {'level': 3, 'target_percentage': 50.0, 'quantity_ratio': 0.3}
            ]
        
        return self.current_strategy.get('risk_management', {}).get('take_profit_levels', [])
    
    def should_refresh_strategy(self) -> bool:
        """전략 설정 갱신 여부 판단"""
        if not self.current_strategy:
            return True
        
        # 설정 생성 시간 확인
        metadata = self.current_strategy.get('metadata', {})
        generated_at = metadata.get('config_generated_at')
        
        if not generated_at:
            return True
        
        try:
            generated_time = datetime.fromisoformat(generated_at.replace('Z', '+00:00'))
            current_time = datetime.utcnow()
            
            # 6시간마다 갱신
            if (current_time - generated_time).total_seconds() > 6 * 3600:
                return True
                
        except Exception:
            return True
        
        return False
    
    def execute_phase_logic(self, event: Dict, context) -> Dict:
        """Phase별 메인 로직 실행"""
        try:
            logger.info(f"=== {self.phase_name.title()} Phase 시작 ===")
            
            # 전략 설정 갱신 확인
            if self.should_refresh_strategy():
                logger.info("전략 설정 갱신 중...")
                self.generate_new_strategy_config()
            
            # 현재 전략 정보 로그
            if self.current_strategy:
                position_size = self.get_position_size()
                stop_loss = self.get_stop_loss_config()
                
                logger.info(f"적용된 전략:")
                logger.info(f"  포지션 크기: {position_size:,.0f} KRW")
                logger.info(f"  손절 비율: {stop_loss.get('stop_loss_percentage', 8.0):.1f}%")
                logger.info(f"  익절 단계: {len(self.get_take_profit_levels())}개")
            
            # 여기에 Phase별 실제 로직 구현
            # (기존 각 Phase의 고유 로직을 여기에 통합)
            
            phase_result = self._execute_phase_specific_logic(event, context)
            
            logger.info(f"=== {self.phase_name.title()} Phase 완료 ===")
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'phase': self.phase_name,
                    'result': phase_result,
                    'strategy_applied': True,
                    'timestamp': datetime.utcnow().isoformat()
                })
            }
            
        except Exception as e:
            logger.error(f"{self.phase_name} 실행 실패: {e}")
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': str(e),
                    'phase': self.phase_name,
                    'strategy_applied': False
                })
            }
    
    def _execute_phase_specific_logic(self, event: Dict, context) -> Dict:
        """Phase별 특화 로직 (각 Phase마다 다르게 구현)"""
        
        # pattern_analyzer 특화 로직
        if self.phase_name == 'ticker_scanner':
            return self._scanner_logic(event, context)
        elif self.phase_name == 'data_collector':
            return self._collector_logic(event, context)
        elif self.phase_name == 'pattern_analyzer':
            return self._analyzer_logic(event, context)
        elif self.phase_name == 'position_manager':
            return self._position_logic(event, context)
        elif self.phase_name == 'risk_monitor':
            return self._risk_logic(event, context)
        elif self.phase_name == 'portfolio_optimizer':
            return self._optimizer_logic(event, context)
        elif self.phase_name == 'performance_tracker':
            return self._tracker_logic(event, context)
        else:
            return {'message': f'{self.phase_name} 기본 로직 실행 완료'}
    
    def _scanner_logic(self, event: Dict, context) -> Dict:
        """Ticker Scanner 로직"""
        # 시간대 기반 스캔 간격 조정
        strategy = self.current_strategy or {}
        scan_interval = strategy.get('phase_specific', {}).get('scan_interval_minutes', 5)
        
        return {
            'action': 'ticker_scan',
            'scan_interval_minutes': scan_interval,
            'strategy_enhanced': bool(self.strategy_enhancer)
        }
    
    def _collector_logic(self, event: Dict, context) -> Dict:
        """Data Collector 로직"""
        return {
            'action': 'data_collection',
            'indicators_calculated': ['RSI', 'MACD', 'BB', 'ADX'],
            'strategy_enhanced': bool(self.strategy_enhancer)
        }
    
    def _analyzer_logic(self, event: Dict, context) -> Dict:
        """Pattern Analyzer 로직"""
        return {
            'action': 'pattern_analysis',
            'patterns_detected': [],
            'strategy_enhanced': bool(self.strategy_enhancer)
        }
    
    def _position_logic(self, event: Dict, context) -> Dict:
        """Position Manager 로직"""
        position_size = self.get_position_size()
        
        return {
            'action': 'position_management',
            'position_size_krw': position_size,
            'strategy_enhanced': bool(self.strategy_enhancer)
        }
    
    def _risk_logic(self, event: Dict, context) -> Dict:
        """Risk Monitor 로직"""
        stop_loss = self.get_stop_loss_config()
        take_profit = self.get_take_profit_levels()
        
        return {
            'action': 'risk_monitoring',
            'stop_loss_pct': stop_loss.get('stop_loss_percentage', 8.0),
            'take_profit_levels': len(take_profit),
            'strategy_enhanced': bool(self.strategy_enhancer)
        }
    
    def _optimizer_logic(self, event: Dict, context) -> Dict:
        """Portfolio Optimizer 로직"""
        return {
            'action': 'portfolio_optimization',
            'optimization_applied': True,
            'strategy_enhanced': bool(self.strategy_enhancer)
        }
    
    def _tracker_logic(self, event: Dict, context) -> Dict:
        """Performance Tracker 로직"""
        return {
            'action': 'performance_tracking',
            'metrics_updated': True,
            'strategy_enhanced': bool(self.strategy_enhancer)
        }

# Lambda 핸들러
def lambda_handler(event, context):
    """Lambda 진입점"""
    try:
        enhanced_phase = EnhancedPatternAnalyzer()
        return enhanced_phase.execute_phase_logic(event, context)
        
    except Exception as e:
        logger.error(f"makenaide-pattern-analyzer Lambda 실행 실패: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'function': 'makenaide-pattern-analyzer'
            })
        }
