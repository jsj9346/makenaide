import json
import logging
import os
import urllib.request
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """실제 RDB 적재 메인 핸들러 (수정됨)"""
    try:
        logger.info("🚀 Makenaide RDB 적재 시작")
        start_time = datetime.now()
        
        # 1. psycopg2 import 확인
        try:
            import psycopg2
            logger.info("✅ psycopg2 import 성공")
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': f'psycopg2 import 실패: {str(e)}',
                    'timestamp': datetime.now().isoformat()
                })
            }
        
        # 2. Upbit 티커 조회
        try:
            url = "https://api.upbit.com/v1/market/all"
            
            with urllib.request.urlopen(url, timeout=10) as response:
                data = json.loads(response.read().decode())
                
            krw_tickers = [
                market['market'] for market in data 
                if market['market'].startswith('KRW-')
            ]
            
            logger.info(f"Upbit에서 {len(krw_tickers)}개 티커 조회 완료")
            
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': f'Upbit API 오류: {str(e)}',
                    'timestamp': datetime.now().isoformat()
                })
            }
        
        # 3. DB 연결 및 데이터 삽입
        try:
            conn = psycopg2.connect(
                host=os.environ.get('PG_HOST'),
                port=int(os.environ.get('PG_PORT', 5432)),
                database=os.environ.get('PG_DATABASE'),
                user=os.environ.get('PG_USER'),
                password=os.environ.get('PG_PASSWORD'),
                connect_timeout=10
            )
            
            cursor = conn.cursor()
            
            # 기존 티커 조회
            cursor.execute("SELECT ticker FROM tickers")
            existing_tickers = set(row[0] for row in cursor.fetchall())
            
            # 신규 티커 삽입
            new_tickers = set(krw_tickers) - existing_tickers
            inserted_count = 0
            
            for ticker in new_tickers:
                try:
                    cursor.execute("""
                        INSERT INTO tickers (ticker, created_at, is_active) 
                        VALUES (%s, CURRENT_TIMESTAMP, true)
                    """, (ticker,))
                    inserted_count += 1
                except Exception as e:
                    logger.warning(f"티커 {ticker} 삽입 실패: {e}")
            
            conn.commit()
            
            # 최종 상태 확인
            cursor.execute("SELECT COUNT(*) FROM tickers")
            total_tickers = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM tickers WHERE is_active = true")
            active_tickers = cursor.fetchone()[0]
            
            cursor.close()
            conn.close()
            
            execution_time = (datetime.now() - start_time).total_seconds()
            
            logger.info(f"✅ RDB 적재 완료: {inserted_count}개 신규 삽입")
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': '🎉 RDB 적재 성공!',
                    'upbit_tickers': len(krw_tickers),
                    'existing_tickers': len(existing_tickers),
                    'new_tickers_inserted': inserted_count,
                    'total_tickers_in_db': total_tickers,
                    'active_tickers_in_db': active_tickers,
                    'execution_time': execution_time,
                    'timestamp': datetime.now().isoformat()
                })
            }
            
        except Exception as e:
            logger.error(f"DB 작업 실패: {e}")
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': f'DB 작업 실패: {str(e)}',
                    'upbit_tickers': len(krw_tickers) if 'krw_tickers' in locals() else 0,
                    'timestamp': datetime.now().isoformat()
                })
            }
        
    except Exception as e:
        logger.error(f"전체 프로세스 실패: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            })
        }